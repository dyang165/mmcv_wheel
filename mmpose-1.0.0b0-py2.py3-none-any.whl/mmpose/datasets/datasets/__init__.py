# Copyright (c) OpenMMLab. All rights reserved.
from .animal import *  # noqa: F401, F403
from .base import *  # noqa: F401, F403
from .body import *  # noqa: F401, F403
from .face import *  # noqa: F401, F403
from .fashion import *  # noqa: F401, F403
from .hand import *  # noqa: F401, F403
from .wholebody import *  # noqa: F401, F403
