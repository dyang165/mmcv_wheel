# Copyright (c) OpenMMLab. All rights reserved.
from .deepfashion_dataset import DeepFashionDataset

__all__ = ['DeepFashionDataset']
