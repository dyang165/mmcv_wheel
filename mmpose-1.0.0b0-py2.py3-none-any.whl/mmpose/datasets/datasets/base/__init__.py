# Copyright (c) OpenMMLab. All rights reserved.
from .base_coco_style_dataset import BaseCocoStyleDataset

__all__ = ['BaseCocoStyleDataset']
