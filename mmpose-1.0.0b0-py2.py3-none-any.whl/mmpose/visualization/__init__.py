# Copyright (c) OpenMMLab. All rights reserved.
from .local_visualizer import PoseLocalVisualizer

__all__ = ['PoseLocalVisualizer']
