# Copyright (c) OpenMMLab. All rights reserved.
from .topdown import TopdownPoseEstimator

__all__ = ['TopdownPoseEstimator']
